Kerala Play V15 Mobile FIXED
Replace only index.html in the GitHub root.
House button now appears within 12m of a house and is labelled 🏠 Enter.
