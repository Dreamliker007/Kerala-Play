V16 Multiplayer Mobile
Join the same Kerala Play room using Supabase Realtime Broadcast. This is a lightweight prototype: player positions are live-synced, with no persistent account system yet. Replace only index.html in GitHub.
